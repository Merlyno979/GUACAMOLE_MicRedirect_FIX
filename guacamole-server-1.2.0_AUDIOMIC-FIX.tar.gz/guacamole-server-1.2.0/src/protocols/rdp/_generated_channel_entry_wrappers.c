#include "plugins/channels.h"
#include <freerdp/channels/channels.h>
#include <freerdp/freerdp.h>
static BOOL guac_rdp_plugin_entry_ex_wrapper1(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[1 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper2(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[2 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper3(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[3 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper4(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[4 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper5(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[5 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper6(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[6 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper7(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[7 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper8(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[8 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper9(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[9 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper10(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[10 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper11(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[11 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper12(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[12 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper13(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[13 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper14(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[14 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper15(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[15 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper16(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[16 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper17(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[17 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper18(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[18 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper19(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[19 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper20(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[20 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper21(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[21 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper22(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[22 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper23(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[23 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper24(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[24 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper25(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[25 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper26(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[26 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper27(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[27 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper28(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[28 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper29(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[29 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper30(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[30 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper31(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[31 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper32(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[32 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper33(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[33 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper34(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[34 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper35(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[35 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper36(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[36 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper37(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[37 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper38(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[38 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper39(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[39 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper40(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[40 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper41(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[41 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper42(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[42 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper43(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[43 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper44(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[44 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper45(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[45 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper46(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[46 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper47(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[47 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper48(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[48 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper49(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[49 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper50(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[50 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper51(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[51 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper52(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[52 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper53(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[53 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper54(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[54 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper55(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[55 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper56(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[56 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper57(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[57 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper58(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[58 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper59(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[59 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper60(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[60 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper61(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[61 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper62(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[62 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper63(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[63 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_ex_wrapper64(PCHANNEL_ENTRY_POINTS_EX entry_points_ex, PVOID init_handle) {
    return guac_rdp_wrapped_entry_ex[64 - 1](entry_points_ex, init_handle);
}
static BOOL guac_rdp_plugin_entry_wrapper1(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[1 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper2(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[2 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper3(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[3 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper4(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[4 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper5(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[5 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper6(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[6 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper7(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[7 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper8(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[8 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper9(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[9 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper10(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[10 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper11(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[11 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper12(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[12 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper13(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[13 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper14(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[14 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper15(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[15 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper16(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[16 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper17(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[17 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper18(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[18 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper19(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[19 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper20(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[20 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper21(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[21 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper22(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[22 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper23(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[23 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper24(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[24 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper25(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[25 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper26(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[26 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper27(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[27 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper28(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[28 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper29(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[29 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper30(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[30 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper31(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[31 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper32(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[32 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper33(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[33 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper34(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[34 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper35(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[35 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper36(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[36 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper37(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[37 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper38(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[38 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper39(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[39 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper40(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[40 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper41(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[41 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper42(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[42 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper43(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[43 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper44(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[44 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper45(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[45 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper46(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[46 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper47(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[47 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper48(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[48 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper49(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[49 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper50(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[50 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper51(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[51 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper52(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[52 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper53(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[53 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper54(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[54 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper55(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[55 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper56(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[56 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper57(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[57 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper58(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[58 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper59(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[59 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper60(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[60 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper61(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[61 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper62(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[62 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper63(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[63 - 1](entry_points);
}
static BOOL guac_rdp_plugin_entry_wrapper64(PCHANNEL_ENTRY_POINTS entry_points) {
    return guac_rdp_wrapped_entry[64 - 1](entry_points);
}
PVIRTUALCHANNELENTRYEX guac_rdp_entry_ex_wrappers[64] = {
    guac_rdp_plugin_entry_ex_wrapper1,
    guac_rdp_plugin_entry_ex_wrapper2,
    guac_rdp_plugin_entry_ex_wrapper3,
    guac_rdp_plugin_entry_ex_wrapper4,
    guac_rdp_plugin_entry_ex_wrapper5,
    guac_rdp_plugin_entry_ex_wrapper6,
    guac_rdp_plugin_entry_ex_wrapper7,
    guac_rdp_plugin_entry_ex_wrapper8,
    guac_rdp_plugin_entry_ex_wrapper9,
    guac_rdp_plugin_entry_ex_wrapper10,
    guac_rdp_plugin_entry_ex_wrapper11,
    guac_rdp_plugin_entry_ex_wrapper12,
    guac_rdp_plugin_entry_ex_wrapper13,
    guac_rdp_plugin_entry_ex_wrapper14,
    guac_rdp_plugin_entry_ex_wrapper15,
    guac_rdp_plugin_entry_ex_wrapper16,
    guac_rdp_plugin_entry_ex_wrapper17,
    guac_rdp_plugin_entry_ex_wrapper18,
    guac_rdp_plugin_entry_ex_wrapper19,
    guac_rdp_plugin_entry_ex_wrapper20,
    guac_rdp_plugin_entry_ex_wrapper21,
    guac_rdp_plugin_entry_ex_wrapper22,
    guac_rdp_plugin_entry_ex_wrapper23,
    guac_rdp_plugin_entry_ex_wrapper24,
    guac_rdp_plugin_entry_ex_wrapper25,
    guac_rdp_plugin_entry_ex_wrapper26,
    guac_rdp_plugin_entry_ex_wrapper27,
    guac_rdp_plugin_entry_ex_wrapper28,
    guac_rdp_plugin_entry_ex_wrapper29,
    guac_rdp_plugin_entry_ex_wrapper30,
    guac_rdp_plugin_entry_ex_wrapper31,
    guac_rdp_plugin_entry_ex_wrapper32,
    guac_rdp_plugin_entry_ex_wrapper33,
    guac_rdp_plugin_entry_ex_wrapper34,
    guac_rdp_plugin_entry_ex_wrapper35,
    guac_rdp_plugin_entry_ex_wrapper36,
    guac_rdp_plugin_entry_ex_wrapper37,
    guac_rdp_plugin_entry_ex_wrapper38,
    guac_rdp_plugin_entry_ex_wrapper39,
    guac_rdp_plugin_entry_ex_wrapper40,
    guac_rdp_plugin_entry_ex_wrapper41,
    guac_rdp_plugin_entry_ex_wrapper42,
    guac_rdp_plugin_entry_ex_wrapper43,
    guac_rdp_plugin_entry_ex_wrapper44,
    guac_rdp_plugin_entry_ex_wrapper45,
    guac_rdp_plugin_entry_ex_wrapper46,
    guac_rdp_plugin_entry_ex_wrapper47,
    guac_rdp_plugin_entry_ex_wrapper48,
    guac_rdp_plugin_entry_ex_wrapper49,
    guac_rdp_plugin_entry_ex_wrapper50,
    guac_rdp_plugin_entry_ex_wrapper51,
    guac_rdp_plugin_entry_ex_wrapper52,
    guac_rdp_plugin_entry_ex_wrapper53,
    guac_rdp_plugin_entry_ex_wrapper54,
    guac_rdp_plugin_entry_ex_wrapper55,
    guac_rdp_plugin_entry_ex_wrapper56,
    guac_rdp_plugin_entry_ex_wrapper57,
    guac_rdp_plugin_entry_ex_wrapper58,
    guac_rdp_plugin_entry_ex_wrapper59,
    guac_rdp_plugin_entry_ex_wrapper60,
    guac_rdp_plugin_entry_ex_wrapper61,
    guac_rdp_plugin_entry_ex_wrapper62,
    guac_rdp_plugin_entry_ex_wrapper63,
    guac_rdp_plugin_entry_ex_wrapper64,
};
PVIRTUALCHANNELENTRY guac_rdp_entry_wrappers[64] = {
    guac_rdp_plugin_entry_wrapper1,
    guac_rdp_plugin_entry_wrapper2,
    guac_rdp_plugin_entry_wrapper3,
    guac_rdp_plugin_entry_wrapper4,
    guac_rdp_plugin_entry_wrapper5,
    guac_rdp_plugin_entry_wrapper6,
    guac_rdp_plugin_entry_wrapper7,
    guac_rdp_plugin_entry_wrapper8,
    guac_rdp_plugin_entry_wrapper9,
    guac_rdp_plugin_entry_wrapper10,
    guac_rdp_plugin_entry_wrapper11,
    guac_rdp_plugin_entry_wrapper12,
    guac_rdp_plugin_entry_wrapper13,
    guac_rdp_plugin_entry_wrapper14,
    guac_rdp_plugin_entry_wrapper15,
    guac_rdp_plugin_entry_wrapper16,
    guac_rdp_plugin_entry_wrapper17,
    guac_rdp_plugin_entry_wrapper18,
    guac_rdp_plugin_entry_wrapper19,
    guac_rdp_plugin_entry_wrapper20,
    guac_rdp_plugin_entry_wrapper21,
    guac_rdp_plugin_entry_wrapper22,
    guac_rdp_plugin_entry_wrapper23,
    guac_rdp_plugin_entry_wrapper24,
    guac_rdp_plugin_entry_wrapper25,
    guac_rdp_plugin_entry_wrapper26,
    guac_rdp_plugin_entry_wrapper27,
    guac_rdp_plugin_entry_wrapper28,
    guac_rdp_plugin_entry_wrapper29,
    guac_rdp_plugin_entry_wrapper30,
    guac_rdp_plugin_entry_wrapper31,
    guac_rdp_plugin_entry_wrapper32,
    guac_rdp_plugin_entry_wrapper33,
    guac_rdp_plugin_entry_wrapper34,
    guac_rdp_plugin_entry_wrapper35,
    guac_rdp_plugin_entry_wrapper36,
    guac_rdp_plugin_entry_wrapper37,
    guac_rdp_plugin_entry_wrapper38,
    guac_rdp_plugin_entry_wrapper39,
    guac_rdp_plugin_entry_wrapper40,
    guac_rdp_plugin_entry_wrapper41,
    guac_rdp_plugin_entry_wrapper42,
    guac_rdp_plugin_entry_wrapper43,
    guac_rdp_plugin_entry_wrapper44,
    guac_rdp_plugin_entry_wrapper45,
    guac_rdp_plugin_entry_wrapper46,
    guac_rdp_plugin_entry_wrapper47,
    guac_rdp_plugin_entry_wrapper48,
    guac_rdp_plugin_entry_wrapper49,
    guac_rdp_plugin_entry_wrapper50,
    guac_rdp_plugin_entry_wrapper51,
    guac_rdp_plugin_entry_wrapper52,
    guac_rdp_plugin_entry_wrapper53,
    guac_rdp_plugin_entry_wrapper54,
    guac_rdp_plugin_entry_wrapper55,
    guac_rdp_plugin_entry_wrapper56,
    guac_rdp_plugin_entry_wrapper57,
    guac_rdp_plugin_entry_wrapper58,
    guac_rdp_plugin_entry_wrapper59,
    guac_rdp_plugin_entry_wrapper60,
    guac_rdp_plugin_entry_wrapper61,
    guac_rdp_plugin_entry_wrapper62,
    guac_rdp_plugin_entry_wrapper63,
    guac_rdp_plugin_entry_wrapper64,
};
